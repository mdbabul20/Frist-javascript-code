document.write(
    "hello world <br/> im here"
);




var name =" <br/> Babul ";
var secondName=" Hossain";
var age,number;
age="34 ";
 number="01947886920";


var fullName= (name+secondName);

document.write(fullName);

document.write("My Name is " + name+ secondName);
document.write (fullName+ secondName+" here Im <br/> ");

document.write(age+number);





// this is another part of javascript 

document.write(" <br/> <br/> <br/> this is another part of javascript for anshul islam <br/>");


console.log('this is another part of javascript');
// kibabe number data type ke string a kora jay.
var num =20;
num=toString(num);

console.log(typeof(num));

//kibabe string ke number a porinoto kora jay.
var name = "hello world";
console.log( typeof Number("35"));


// kibabe dosomit ar porer koyta number dekano jay aita set kora jay
var num2=34.586;
console.log(num2.toFixed(2));
console.log(num2.toPrecision(3));





// string number ar libabary 
var bdname="Bangladesh <br/>";
var len =bdname.length;
 
document.write(len + "<br/>");


// how to take user input 





// string UPPERCASE
var names1="Babul Hossen <br/> ";
var nam1=names1.toUpperCase;
document.write(names1.toUpperCase());




// anonther part of 
// part of 10 tutorial anishul islam

var num1=10;
var num2=20;

num1 = parseInt(num1, 10);
num2 = parseInt(num2, 10);

var sum,suy;

sum = num1 + num2;
document.write("your sum : " + sum + "<br/>");

suy = num1 - num2;
document.write("your sub : " + suy + "<br/>");

var into,dibe,modulase;

into = num1 * num2;
document.write("Your Into : " + into + "<br/>");


dibe = num1 / num2;
document.write("YOur Dibe : " + dibe + "<br/>");


modulase = num1 / num2;
document.write("YOur Modulase : " + modulase + "<br/>");



// another part of parseFloat and 11 anishul islam 

// var numberone =parseFloat( prompt(' Enter YOur Frist number'));
// var numbertwo = parseFloat( prompt(' Enter YOur second number'));

// var mut = (numberone + numbertwo) * 2;
// document.write('mut = ' + mut + "<br/>");



// part of farenhite to calse and calse to fahernhite part number 12

var far = 23;
var cels = 32;

var cel = (far - 32) * (5/9);
document.write("Your Cel.. : " + cel + '<br/>');



var farh = (cels * 9/5) + 32;
document.write("Your Fahr.. : " + farh + "<br/>");


// part of logincale operator && holo jokon sob gulu condition right hobe tokon true dekabe 
// arr || ata holo jokon sob conditon teke jekono aktaw sotik hole tokon true dekabe arr jdi aktaw sotik nah tahole false dekabe 
//  arr ! ata holo not ortart true takle false return korbe arr false takle true returns korbe..

var numberthree = 20;
var numberfour = 30;
var numberfive = 50;

var jokfulone;

jokfulone = (numberthree > numberfive && numberfive> numberfour && numberfour>numberthree);

document.write("jokfulone : " + jokfulone + "<br/>");


jokfulone = (numberfive>numberthree && numberthree<numberfour && numberfour<numberfive);

document.write("jokfultwo ; " +jokfulone + "<br/>");


jokfulone = (numberfive<numberthree || numberthree>numberfour || numberfour>numberfive);

document.write("jokfulthree ; " +jokfulone + "<br/>");


jokfulfour = (numberfive<numberthree || numberthree<numberfour || numberfour<numberfive);

document.write("jokfulfour ; " +jokfulfour + "<br/>");




jokfulfour = !(numberfour < numberfive);

document.write("jokfulfive ; " +jokfulfour + "<br/>");


// part of 14/15 in anishul islam 

var mark= 56;

if (mark >= 80)(
    document.write("A+")
);
   

else if (mark >= 70)(
    document.write("A")
);

else if (mark >= 60)(
    document.write("A-")
);

else if (mark >= 33)(
    document.write("F")
);
  
 else (document.write("fails,,,"));


 document.write("<br/>");
// part of 16 anishul islam if else with logical operator
//  which number is large in threee number 
var fnumber = 20;
var snumber = 43;
var tnumber = 23;

if(fnumber>snumber && fnumber>tnumber)
document.write("Large Number is :" + snumber);

else if (snumber>fnumber && snumber>tnumber)
document.write(" Large number is : " + snumber);
 else document.write("large number is : " + tnumber);


 document.write("<br/>");

//  another example of if else

 var letter = "A";
letter = letter.toLowerCase();
 if (letter=="a" || letter=="e" || letter=="i" || letter=="o" || letter=="u")
document.write("vowel");

else document.write("consolated");






// part of 17 in anishul islam of switch is all most if else;

document.write("<br/>");
var digit = 4;

switch (digit){
    case(1):
    document.write("one")
    break;
    case(2):
    document.write("two")
    break;
    case(3):
    document.write("three")
    break;
    case(4):
    document.write("four")
    break;
    case(5):
    document.write("five")
    break;
    case(6):
    document.write("six")
    break;
    default :
    document.write("No Digit")
    
};

document.write("<br/>");



//  another part of 18 for loop in anishul islam

for (var x=1; x <= 5; x=x+1){
    document.write(x );
};

document.write("<br/>");

for (var x=3; x <= 21; x=x+3){
    document.write(x );
};

document.write("<br/>");


// 1-5 ti sonkar jok ful
 var sum=0;

for (var x=1; x <= 5; x++){
    var sum =x+sum;
};

document.write(sum);
document.write("<br/>");

for(var x=1; x <= 3; x++){
    var numm1 =3;
    var numm2 =5;
    
var summ = numm1 + numm2;
document.write("result" + summ);
document.write("<br/>");

};

document.write("<br/>");



//  TASK 6 amon sonka nite hobe jegulu 3/5 dara bag korar por bag ses 0 hobe and 1-50 arr modde
// most important and very toup
var summ = 0;
var x=1;
while (x<=50)
{ if(x%3==0 && x%5==0)(
    document.write(" " + x +'  ')
)
summ = x+summ;

x++; 
}

document.write(summ);

document.write("<br/>");

// part of 22 break and contiune 
for (x=1; x<=5; x=x+1){
    if(x==3){
        break;
    };
    document.write(" " + x);
}
document.write("<br/>");

for (x=1; x<=5; x=x+1){
    if(x==3){
        continue;
    };
    document.write(" " + x);
}

document.write("<br/>");


// tenarary operator arr bebhar.. part of 23 anishul islam

var nummm = 2;
var resultt = nummm>0 ? "positive" : nummm<0 ? "negative" : "zero";
document.write(resultt);

// part of 24 anishul islam in.... 